package com.example.myapplication

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication.databinding.ActivityMainBinding
import com.example.myapplication.databinding.DialogAuthBinding
import com.example.myapplication.ui.AuthViewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    private val authViewModel: AuthViewModel by viewModels()

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (data != null) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            authViewModel.handleSignInResult(task)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setSupportActionBar(binding.toolbar)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_content_main) as NavHostFragment
        val navController = navHostFragment.navController

        appBarConfiguration = AppBarConfiguration(
            setOf(R.id.navigation_scan, R.id.navigation_saved)
        )

        setupActionBarWithNavController(navController, appBarConfiguration)
        binding.contentMain.bottomNavigation.setupWithNavController(navController)

        observeAuthViewModel()
    }

    private fun observeAuthViewModel() {
        authViewModel.toastMessage.observe(this) { message ->
            if (!message.isNullOrBlank()) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                authViewModel.clearToast()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_account -> {
                showAuthDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAuthDialog() {
        val dialogBinding = DialogAuthBinding.inflate(layoutInflater)
        val user = authViewModel.userProfile.value

        if (user != null) {
            dialogBinding.tvAuthTitle.text = user.displayName ?: "User Profile"
            dialogBinding.tvAuthSubtitle.text = user.email ?: "Signed in with Google"
            dialogBinding.btnSignInGoogle.visibility = View.GONE
            dialogBinding.btnSignOut.visibility = View.VISIBLE
        } else {
            dialogBinding.tvAuthTitle.text = getString(R.string.account)
            dialogBinding.tvAuthSubtitle.text = "Sign in to sync your saved vocabulary"
            dialogBinding.btnSignInGoogle.visibility = View.VISIBLE
            dialogBinding.btnSignOut.visibility = View.GONE
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(dialogBinding.root)
            .setPositiveButton("Close", null)
            .create()

        dialogBinding.btnSignInGoogle.setOnClickListener {
            dialog.dismiss()
            val intent = authViewModel.getGoogleSignInIntent(this)
            if (intent != null) {
                googleSignInLauncher.launch(intent)
            }
        }

        dialogBinding.btnSignOut.setOnClickListener {
            dialog.dismiss()
            authViewModel.signOut(this)
        }

        dialog.show()
    }

    override fun onSupportNavigateUp(): Boolean {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment_content_main) as NavHostFragment
        val navController = navHostFragment.navController
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}
