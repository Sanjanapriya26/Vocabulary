package com.example.myapplication.ui

import android.app.Application
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.api.DictionaryApiService
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.model.SavedWord
import com.example.myapplication.data.repository.DictionaryResult
import com.example.myapplication.data.repository.VocabularyRepository
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch

sealed class DefinitionUiState {
    object Idle : DefinitionUiState()
    object Loading : DefinitionUiState()
    data class Success(
        val word: String,
        val phonetic: String,
        val partOfSpeech: String,
        val definition: String,
        val example: String,
        val audioUrl: String?,
        val isSaved: Boolean
    ) : DefinitionUiState()
    object NotFound : DefinitionUiState()
    data class Error(val message: String) : DefinitionUiState()
}

class ScanViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VocabularyRepository
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val _definitionState = MutableLiveData<DefinitionUiState>(DefinitionUiState.Idle)
    val definitionState: LiveData<DefinitionUiState> = _definitionState

    private val _recognizedWords = MutableLiveData<List<String>>(emptyList())
    val recognizedWords: LiveData<List<String>> = _recognizedWords

    private val _isAnalyzingText = MutableLiveData(false)
    val isAnalyzingText: LiveData<Boolean> = _isAnalyzingText

    private val _audioPlaybackState = MutableLiveData(false)
    val audioPlaybackState: LiveData<Boolean> = _audioPlaybackState

    private val _toastMessage = MutableLiveData<String?>()
    val toastMessage: LiveData<String?> = _toastMessage

    private var mediaPlayer: MediaPlayer? = null

    init {
        val database = AppDatabase.getInstance(application)
        val apiService = DictionaryApiService.create()
        repository = VocabularyRepository(apiService, database.wordDao())
    }

    fun processImage(bitmap: Bitmap) {
        _isAnalyzingText.value = true
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                _isAnalyzingText.value = false
                val text = visionText.text
                val words = extractWords(text)
                _recognizedWords.value = words
            }
            .addOnFailureListener { e ->
                _isAnalyzingText.value = false
                _toastMessage.value = "Text recognition failed: ${e.localizedMessage}"
            }
    }

    fun loadSampleText() {
        val sampleText = "Vocabulary reading skills comprehension definition language learning scanner dictionary application"
        _recognizedWords.value = extractWords(sampleText)
    }

    private fun extractWords(text: String): List<String> {
        return text.split(Regex("[\\s,.?!:;\"()\\[\\]{}/\\\\#*+=~`]+"))
            .asSequence()
            .map { word -> word.lowercase().filter { char -> char.isLetter() || (char == '-') } }
            .filter { word -> word.length > 1 && word.any { it.isLetter() } }
            .distinct()
            .toList()
    }

    fun lookupWord(word: String) {
        val clean = word.trim().lowercase().filter { it.isLetter() || it == '-' }
        if (clean.isEmpty()) return

        _definitionState.value = DefinitionUiState.Loading

        viewModelScope.launch {
            when (val result = repository.fetchWordDefinition(clean)) {
                is DictionaryResult.Success -> {
                    val entry = result.entry
                    val wordTitle = entry.word ?: clean
                    val phoneticText = entry.phonetic
                        ?: entry.phonetics?.firstOrNull { !it.text.isNullOrBlank() }?.text
                        ?: ""
                    val firstMeaning = entry.meanings?.firstOrNull()
                    val partOfSpeech = firstMeaning?.partOfSpeech ?: ""
                    val firstDef = firstMeaning?.definitions?.firstOrNull()
                    val definition = firstDef?.definition ?: "No definition provided."
                    val example = firstDef?.example ?: ""
                    val audioUrl = result.audioUrl

                    val existingSaved = repository.isWordSaved(wordTitle)
                    val isSaved = existingSaved != null

                    _definitionState.value = DefinitionUiState.Success(
                        word = wordTitle,
                        phonetic = phoneticText,
                        partOfSpeech = partOfSpeech,
                        definition = definition,
                        example = example,
                        audioUrl = audioUrl,
                        isSaved = isSaved
                    )
                }
                is DictionaryResult.NotFound -> {
                    _definitionState.value = DefinitionUiState.NotFound
                }
                is DictionaryResult.Error -> {
                    _definitionState.value = DefinitionUiState.Error(result.message)
                }
            }
        }
    }

    fun saveCurrentWord() {
        val state = _definitionState.value as? DefinitionUiState.Success ?: return
        viewModelScope.launch {
            val savedWord = SavedWord(
                word = state.word,
                phonetic = state.phonetic,
                partOfSpeech = state.partOfSpeech,
                definition = state.definition,
                example = state.example,
                audioUrl = state.audioUrl ?: "",
                isLearned = false
            )
            repository.saveWord(savedWord)
            _definitionState.value = state.copy(isSaved = true)
            _toastMessage.value = "'${state.word}' saved to vocabulary!"
        }
    }

    fun playAudio(audioUrl: String?) {
        if (audioUrl.isNullOrBlank()) {
            _toastMessage.value = "No audio pronunciation available."
            return
        }

        try {
            stopAudio()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(audioUrl)
                setOnPreparedListener { mp ->
                    _audioPlaybackState.postValue(true)
                    mp.start()
                }
                setOnCompletionListener {
                    _audioPlaybackState.postValue(false)
                    stopAudio()
                }
                setOnErrorListener { _, _, _ ->
                    _audioPlaybackState.postValue(false)
                    _toastMessage.postValue("Audio playback failed.")
                    stopAudio()
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            _toastMessage.value = "Failed to play audio: ${e.message}"
            _audioPlaybackState.value = false
        }
    }

    fun stopAudio() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
        _audioPlaybackState.value = false
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        stopAudio()
    }
}
