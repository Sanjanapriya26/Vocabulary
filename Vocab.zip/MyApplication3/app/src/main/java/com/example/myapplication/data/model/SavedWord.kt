package com.example.myapplication.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_words")
data class SavedWord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val word: String,
    val phonetic: String = "",
    val partOfSpeech: String = "",
    val definition: String = "",
    val example: String = "",
    val audioUrl: String = "",
    val isLearned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
