package com.example.myapplication.ui

import android.app.Application
import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.api.DictionaryApiService
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.model.SavedWord
import com.example.myapplication.data.repository.VocabularyRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

enum class FilterType {
    ALL, NOT_LEARNED, LEARNED
}

data class VocabStats(
    val total: Int = 0,
    val learned: Int = 0,
    val notLearned: Int = 0
)

class SavedWordsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VocabularyRepository
    private val selectedFilter = MutableStateFlow(FilterType.ALL)

    private val allWordsFlow = AppDatabase.getInstance(application).wordDao().getAllWords()

    @OptIn(ExperimentalCoroutinesApi::class)
    val savedWords: LiveData<List<SavedWord>> = selectedFilter
        .flatMapLatest { filter ->
            when (filter) {
                FilterType.ALL -> repository.getAllSavedWords()
                FilterType.NOT_LEARNED -> repository.getSavedWordsByStatus(isLearned = false)
                FilterType.LEARNED -> repository.getSavedWordsByStatus(isLearned = true)
            }
        }
        .asLiveData()

    val stats: LiveData<VocabStats> = allWordsFlow.combine(selectedFilter) { list, _ ->
        val total = list.size
        val learned = list.count { it.isLearned }
        val notLearned = total - learned
        VocabStats(total, learned, notLearned)
    }.asLiveData()

    private val _toastMessage = MutableLiveData<String?>()
    val toastMessage: LiveData<String?> = _toastMessage

    private var mediaPlayer: MediaPlayer? = null

    init {
        val database = AppDatabase.getInstance(application)
        val apiService = DictionaryApiService.create()
        repository = VocabularyRepository(apiService, database.wordDao())
    }

    fun setFilter(filter: FilterType) {
        selectedFilter.value = filter
    }

    fun toggleLearnedStatus(word: SavedWord) {
        viewModelScope.launch {
            repository.toggleLearnedStatus(word)
            val newStatus = if (!word.isLearned) "Learned" else "Not Learned"
            _toastMessage.value = "'${word.word}' marked as $newStatus"
        }
    }

    fun deleteWord(word: SavedWord) {
        viewModelScope.launch {
            repository.deleteWord(word)
            _toastMessage.value = "'${word.word}' deleted"
        }
    }

    fun playAudio(audioUrl: String?) {
        if (audioUrl.isNullOrBlank()) {
            _toastMessage.value = "No audio available"
            return
        }
        try {
            stopAudio()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(audioUrl)
                setOnPreparedListener { mp -> mp.start() }
                setOnCompletionListener { stopAudio() }
                setOnErrorListener { _, _, _ ->
                    _toastMessage.postValue("Playback error")
                    stopAudio()
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            _toastMessage.value = "Failed to play audio"
        }
    }

    fun stopAudio() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        stopAudio()
    }
}
