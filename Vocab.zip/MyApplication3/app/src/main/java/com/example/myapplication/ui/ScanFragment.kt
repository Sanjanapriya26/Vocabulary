package com.example.myapplication.ui

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentScanBinding
import com.google.android.material.chip.Chip

class ScanFragment : Fragment() {

    private var _binding: FragmentScanBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ScanViewModel by viewModels()

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            binding.cardImagePreview.visibility = View.VISIBLE
            binding.imgPreview.setImageBitmap(bitmap)
            viewModel.processImage(bitmap)
        }
    }

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = uriToBitmap(uri)
            if (bitmap != null) {
                binding.cardImagePreview.visibility = View.VISIBLE
                binding.imgPreview.setImageBitmap(bitmap)
                viewModel.processImage(bitmap)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupButtons()
        setupSearch()
        observeViewModel()

        // Load initial sample text if no words recognized yet
        if (viewModel.recognizedWords.value.isNullOrEmpty()) {
            viewModel.loadSampleText()
        }
    }

    private fun setupButtons() {
        binding.btnTakePhoto.setOnClickListener {
            takePictureLauncher.launch(null)
        }

        binding.btnPickImage.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        binding.btnTrySample.setOnClickListener {
            binding.cardImagePreview.visibility = View.GONE
            viewModel.loadSampleText()
        }

        binding.fabAudio.setOnClickListener {
            val state = viewModel.definitionState.value
            if (state is DefinitionUiState.Success) {
                viewModel.playAudio(state.audioUrl)
            }
        }

        binding.btnSaveWord.setOnClickListener {
            viewModel.saveCurrentWord()
        }
    }

    private fun setupSearch() {
        binding.btnSearch.setOnClickListener {
            performSearch()
        }

        binding.etSearchWord.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch()
                true
            } else {
                false
            }
        }
    }

    private fun performSearch() {
        val query = binding.etSearchWord.text?.toString().orEmpty()
        if (query.isNotBlank()) {
            viewModel.lookupWord(query)
        }
    }

    private fun observeViewModel() {
        viewModel.isAnalyzingText.observe(viewLifecycleOwner) { isAnalyzing ->
            binding.progressIndicator.visibility = if (isAnalyzing) View.VISIBLE else View.GONE
        }

        viewModel.recognizedWords.observe(viewLifecycleOwner) { words ->
            populateWordChips(words)
        }

        viewModel.definitionState.observe(viewLifecycleOwner) { state ->
            renderDefinitionState(state)
        }

        viewModel.audioPlaybackState.observe(viewLifecycleOwner) { isPlaying ->
            if (isPlaying) {
                binding.fabAudio.setImageResource(android.R.drawable.ic_media_play)
            } else {
                binding.fabAudio.setImageResource(android.R.drawable.ic_lock_silent_mode_off)
            }
        }

        viewModel.toastMessage.observe(viewLifecycleOwner) { message ->
            if (!message.isNullOrBlank()) {
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                viewModel.clearToastMessage()
            }
        }
    }

    private fun populateWordChips(words: List<String>) {
        binding.chipGroupWords.removeAllViews()

        if (words.isEmpty()) {
            binding.cardRecognizedWords.visibility = View.GONE
            return
        }

        binding.cardRecognizedWords.visibility = View.VISIBLE

        for (word in words) {
            val chip = Chip(requireContext()).apply {
                text = word
                isClickable = true
                isCheckable = false
                setChipBackgroundColorResource(android.R.color.transparent)
                chipStrokeWidth = 2f
                setChipStrokeColorResource(com.google.android.material.R.color.material_dynamic_primary50)
                setOnClickListener {
                    viewModel.lookupWord(word)
                }
            }
            binding.chipGroupWords.addView(chip)
        }
    }

    private fun renderDefinitionState(state: DefinitionUiState) {
        when (state) {
            is DefinitionUiState.Idle -> {
                binding.progressIndicator.visibility = View.GONE
                binding.cardDefinition.visibility = View.GONE
                binding.cardError.visibility = View.GONE
            }
            is DefinitionUiState.Loading -> {
                binding.progressIndicator.visibility = View.VISIBLE
                binding.cardDefinition.visibility = View.GONE
                binding.cardError.visibility = View.GONE
            }
            is DefinitionUiState.Success -> {
                binding.progressIndicator.visibility = View.GONE
                binding.cardError.visibility = View.GONE
                binding.cardDefinition.visibility = View.VISIBLE

                binding.tvDetailWord.text = state.word
                binding.tvDetailPhonetic.text = state.phonetic.ifBlank { "" }
                binding.tvDetailPhonetic.visibility = if (state.phonetic.isBlank()) View.GONE else View.VISIBLE

                if (state.partOfSpeech.isNotBlank()) {
                    binding.chipPartOfSpeech.visibility = View.VISIBLE
                    binding.chipPartOfSpeech.text = state.partOfSpeech
                } else {
                    binding.chipPartOfSpeech.visibility = View.GONE
                }

                binding.tvDetailMeaning.text = state.definition

                if (state.example.isNotBlank()) {
                    binding.tvExampleHeader.visibility = View.VISIBLE
                    binding.tvDetailExample.visibility = View.VISIBLE
                    binding.tvDetailExample.text = state.example
                } else {
                    binding.tvExampleHeader.visibility = View.GONE
                    binding.tvDetailExample.visibility = View.GONE
                }

                if (!state.audioUrl.isNullOrBlank()) {
                    binding.fabAudio.visibility = View.VISIBLE
                } else {
                    binding.fabAudio.visibility = View.GONE
                }

                if (state.isSaved) {
                    binding.btnSaveWord.text = getString(R.string.saved_words)
                    binding.btnSaveWord.isEnabled = false
                } else {
                    binding.btnSaveWord.text = getString(R.string.save_word)
                    binding.btnSaveWord.isEnabled = true
                }
            }
            is DefinitionUiState.NotFound -> {
                binding.progressIndicator.visibility = View.GONE
                binding.cardDefinition.visibility = View.GONE
                binding.cardError.visibility = View.VISIBLE
                binding.tvErrorMessage.text = getString(R.string.word_not_found)
            }
            is DefinitionUiState.Error -> {
                binding.progressIndicator.visibility = View.GONE
                binding.cardDefinition.visibility = View.GONE
                binding.cardError.visibility = View.VISIBLE
                binding.tvErrorMessage.text = state.message
            }
        }
    }

    private fun uriToBitmap(uri: Uri): Bitmap? {
        return try {
            val context = requireContext()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
            }
        } catch (_: Exception) {
            null
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
