package com.example.myapplication.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.model.SavedWord
import com.example.myapplication.databinding.ItemSavedWordBinding

class SavedWordAdapter(
    private val onToggleLearned: (SavedWord) -> Unit,
    private val onPlayAudio: (SavedWord) -> Unit,
    private val onDeleteWord: (SavedWord) -> Unit
) : ListAdapter<SavedWord, SavedWordAdapter.SavedWordViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SavedWordViewHolder {
        val binding = ItemSavedWordBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return SavedWordViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SavedWordViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class SavedWordViewHolder(
        private val binding: ItemSavedWordBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(word: SavedWord) {
            binding.tvSavedWord.text = word.word
            binding.tvSavedPhonetic.text = word.phonetic.ifBlank { "" }
            binding.tvSavedPhonetic.visibility = if (word.phonetic.isBlank()) View.GONE else View.VISIBLE

            binding.tvSavedPartOfSpeech.text = word.partOfSpeech.ifBlank { "word" }
            binding.tvSavedDefinition.text = word.definition.ifBlank { "No definition available." }

            if (word.example.isNotBlank()) {
                binding.tvSavedExample.visibility = View.VISIBLE
                binding.tvSavedExample.text = "Example: ${word.example}"
            } else {
                binding.tvSavedExample.visibility = View.GONE
            }

            // Audio button visibility
            if (word.audioUrl.isNotBlank()) {
                binding.btnPlayAudio.visibility = View.VISIBLE
                binding.btnPlayAudio.setOnClickListener { onPlayAudio(word) }
            } else {
                binding.btnPlayAudio.visibility = View.GONE
            }

            // Status chip and toggle button
            if (word.isLearned) {
                binding.chipStatus.text = "Learned"
                binding.chipStatus.chipBackgroundColor = ColorStateList.valueOf(Color.parseColor("#E8F5E9"))
                binding.chipStatus.setTextColor(Color.parseColor("#2E7D32"))
                binding.btnToggleLearned.text = "Mark as Not Learned"
            } else {
                binding.chipStatus.text = "Not Learned"
                binding.chipStatus.chipBackgroundColor = ColorStateList.valueOf(Color.parseColor("#FFF3E0"))
                binding.chipStatus.setTextColor(Color.parseColor("#E65100"))
                binding.btnToggleLearned.text = "Mark as Learned"
            }

            binding.btnToggleLearned.setOnClickListener { onToggleLearned(word) }
            binding.btnDelete.setOnClickListener { onDeleteWord(word) }
        }
    }

    object DiffCallback : DiffUtil.ItemCallback<SavedWord>() {
        override fun areItemsTheSame(oldItem: SavedWord, newItem: SavedWord): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: SavedWord, newItem: SavedWord): Boolean {
            return oldItem == newItem
        }
    }
}
