package com.example.myapplication.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.myapplication.data.model.SavedWord
import kotlinx.coroutines.flow.Flow

@Dao
interface WordDao {
    @Query("SELECT * FROM saved_words ORDER BY timestamp DESC")
    fun getAllWords(): Flow<List<SavedWord>>

    @Query("SELECT * FROM saved_words WHERE isLearned = :isLearned ORDER BY timestamp DESC")
    fun getWordsByStatus(isLearned: Boolean): Flow<List<SavedWord>>

    @Query("SELECT * FROM saved_words WHERE LOWER(word) = LOWER(:word) LIMIT 1")
    suspend fun getWord(word: String): SavedWord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWord(word: SavedWord): Long

    @Update
    suspend fun updateWord(word: SavedWord)

    @Delete
    suspend fun deleteWord(word: SavedWord)

    @Query("DELETE FROM saved_words WHERE id = :id")
    suspend fun deleteById(id: Long)
}
