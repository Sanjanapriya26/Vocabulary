package com.example.myapplication.data.api

import com.example.myapplication.data.model.WordEntry
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

interface DictionaryApiService {
    @GET("api/v2/entries/en/{word}")
    suspend fun getWordDefinition(@Path("word") word: String): Response<List<WordEntry>>

    companion object {
        private const val BASE_URL = "https://api.dictionaryapi.dev/"

        fun create(): DictionaryApiService {
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(DictionaryApiService::class.java)
        }
    }
}
