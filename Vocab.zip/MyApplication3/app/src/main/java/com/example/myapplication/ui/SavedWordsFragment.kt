package com.example.myapplication.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentSavedWordsBinding

class SavedWordsFragment : Fragment() {

    private var _binding: FragmentSavedWordsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: SavedWordsViewModel by viewModels()
    private lateinit var adapter: SavedWordAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSavedWordsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupFilters()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = SavedWordAdapter(
            onToggleLearned = { word -> viewModel.toggleLearnedStatus(word) },
            onPlayAudio = { word -> viewModel.playAudio(word.audioUrl) },
            onDeleteWord = { word -> viewModel.deleteWord(word) }
        )
        binding.rvSavedWords.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSavedWords.adapter = adapter
    }

    private fun setupFilters() {
        binding.chipGroupFilter.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isEmpty()) return@setOnCheckedStateChangeListener
            when (checkedIds.first()) {
                R.id.chipFilterAll -> viewModel.setFilter(FilterType.ALL)
                R.id.chipFilterNotLearned -> viewModel.setFilter(FilterType.NOT_LEARNED)
                R.id.chipFilterLearned -> viewModel.setFilter(FilterType.LEARNED)
            }
        }
    }

    private fun observeViewModel() {
        viewModel.savedWords.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            if (list.isNullOrEmpty()) {
                binding.viewEmpty.visibility = View.VISIBLE
                binding.rvSavedWords.visibility = View.GONE
            } else {
                binding.viewEmpty.visibility = View.GONE
                binding.rvSavedWords.visibility = View.VISIBLE
            }
        }

        viewModel.stats.observe(viewLifecycleOwner) { stats ->
            binding.tvStats.text = "Total: ${stats.total} | Learned: ${stats.learned} | To Learn: ${stats.notLearned}"
        }

        viewModel.toastMessage.observe(viewLifecycleOwner) { message ->
            if (!message.isNullOrBlank()) {
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                viewModel.clearToastMessage()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
