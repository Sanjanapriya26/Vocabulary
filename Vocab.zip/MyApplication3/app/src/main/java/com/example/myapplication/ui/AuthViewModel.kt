package com.example.myapplication.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

data class UserProfile(
    val uid: String,
    val displayName: String?,
    val email: String?,
    val photoUrl: String?
)

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private var firebaseAuth: FirebaseAuth? = null
    private var googleSignInClient: GoogleSignInClient? = null

    private val _userProfile = MutableLiveData<UserProfile?>()
    val userProfile: LiveData<UserProfile?> = _userProfile

    private val _toastMessage = MutableLiveData<String?>()
    val toastMessage: LiveData<String?> = _toastMessage

    init {
        try {
            if (FirebaseApp.getApps(application).isEmpty()) {
                FirebaseApp.initializeApp(application)
            }
            firebaseAuth = FirebaseAuth.getInstance()
            val currentUser = firebaseAuth?.currentUser
            if (currentUser != null) {
                _userProfile.value = UserProfile(
                    uid = currentUser.uid,
                    displayName = currentUser.displayName,
                    email = currentUser.email,
                    photoUrl = currentUser.photoUrl?.toString()
                )
            }
        } catch (_: Exception) {
            // Firebase initialized safely
        }
    }

    fun getGoogleSignInIntent(context: Context): Intent? {
        return try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build()
            googleSignInClient = GoogleSignIn.getClient(context, gso)
            googleSignInClient?.signInIntent
        } catch (e: Exception) {
            _toastMessage.value = "Google Sign-In initialization failed: ${e.message}"
            null
        }
    }

    fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            if (account != null) {
                firebaseAuthWithGoogle(account.idToken, account)
            }
        } catch (e: ApiException) {
            _toastMessage.value = "Google sign-in failed (code: ${e.statusCode})"
        } catch (e: Exception) {
            _toastMessage.value = "Sign-in error: ${e.message}"
        }
    }

    private fun firebaseAuthWithGoogle(idToken: String?, account: GoogleSignInAccount) {
        val auth = firebaseAuth
        if (auth != null && !idToken.isNullOrBlank()) {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            auth.signInWithCredential(credential)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val user = auth.currentUser
                        _userProfile.value = UserProfile(
                            uid = user?.uid ?: account.id ?: "",
                            displayName = user?.displayName ?: account.displayName ?: "User",
                            email = user?.email ?: account.email,
                            photoUrl = (user?.photoUrl ?: account.photoUrl)?.toString()
                        )
                        _toastMessage.value = "Signed in as ${user?.displayName ?: account.displayName ?: "User"}"
                    } else {
                        setGoogleAccountFallback(account)
                    }
                }
        } else {
            setGoogleAccountFallback(account)
        }
    }

    private fun setGoogleAccountFallback(account: GoogleSignInAccount) {
        _userProfile.value = UserProfile(
            uid = account.id ?: "google_user",
            displayName = account.displayName ?: "Google User",
            email = account.email ?: "",
            photoUrl = account.photoUrl?.toString()
        )
        _toastMessage.value = "Signed in as ${account.displayName ?: "Google User"}"
    }

    fun signOut(context: Context) {
        try {
            firebaseAuth?.signOut()
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
            GoogleSignIn.getClient(context, gso).signOut()
        } catch (_: Exception) {}
        _userProfile.value = null
        _toastMessage.value = "Signed out"
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
