package com.example.myapplication.data.repository

import com.example.myapplication.data.api.DictionaryApiService
import com.example.myapplication.data.local.WordDao
import com.example.myapplication.data.model.SavedWord
import com.example.myapplication.data.model.WordEntry
import kotlinx.coroutines.flow.Flow
import java.io.IOException

sealed class DictionaryResult {
    data class Success(val entry: WordEntry, val audioUrl: String?) : DictionaryResult()
    object NotFound : DictionaryResult()
    data class Error(val message: String) : DictionaryResult()
}

class VocabularyRepository(
    private val apiService: DictionaryApiService,
    private val wordDao: WordDao
) {
    suspend fun fetchWordDefinition(word: String): DictionaryResult {
        val cleanWord = word.trim().lowercase().filter { it.isLetter() || it == '-' }
        if (cleanWord.isEmpty()) {
            return DictionaryResult.Error("Invalid word")
        }
        return try {
            val response = apiService.getWordDefinition(cleanWord)
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val entry = response.body()!!.first()
                val audioUrl = extractAudioUrl(entry)
                DictionaryResult.Success(entry, audioUrl)
            } else if (response.code() == 404) {
                DictionaryResult.NotFound
            } else {
                DictionaryResult.Error("API error: ${response.code()} ${response.message()}")
            }
        } catch (e: IOException) {
            DictionaryResult.Error("Network error. Please check your internet connection.")
        } catch (e: Exception) {
            DictionaryResult.Error(e.localizedMessage ?: "Unknown error occurred")
        }
    }

    private fun extractAudioUrl(entry: WordEntry): String? {
        val phonetics = entry.phonetics ?: return null
        for (p in phonetics) {
            val audio = p.audio
            if (!audio.isNullOrBlank()) {
                return if (audio.startsWith("//")) "https:$audio" else audio
            }
        }
        return null
    }

    fun getAllSavedWords(): Flow<List<SavedWord>> = wordDao.getAllWords()

    fun getSavedWordsByStatus(isLearned: Boolean): Flow<List<SavedWord>> =
        wordDao.getWordsByStatus(isLearned)

    suspend fun saveWord(savedWord: SavedWord) {
        wordDao.insertWord(savedWord)
    }

    suspend fun updateWord(savedWord: SavedWord) {
        wordDao.updateWord(savedWord)
    }

    suspend fun toggleLearnedStatus(savedWord: SavedWord) {
        val updated = savedWord.copy(isLearned = !savedWord.isLearned)
        wordDao.updateWord(updated)
    }

    suspend fun deleteWord(savedWord: SavedWord) {
        wordDao.deleteWord(savedWord)
    }

    suspend fun isWordSaved(word: String): SavedWord? {
        return wordDao.getWord(word)
    }
}
