package com.example.myapplication.data.model

import com.google.gson.annotations.SerializedName

data class WordEntry(
    @SerializedName("word") val word: String? = null,
    @SerializedName("phonetic") val phonetic: String? = null,
    @SerializedName("phonetics") val phonetics: List<Phonetic>? = null,
    @SerializedName("meanings") val meanings: List<Meaning>? = null
)

data class Phonetic(
    @SerializedName("text") val text: String? = null,
    @SerializedName("audio") val audio: String? = null
)

data class Meaning(
    @SerializedName("partOfSpeech") val partOfSpeech: String? = null,
    @SerializedName("definitions") val definitions: List<Definition>? = null
)

data class Definition(
    @SerializedName("definition") val definition: String? = null,
    @SerializedName("example") val example: String? = null
)
